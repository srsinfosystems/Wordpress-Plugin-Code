<?php

/*
 * Plugin Name: Elementor Contact Form DB
 * Plugin URI:  https://www.sean-barton.co.uk/2017/04/elementor-contact-form-db-free-plugin/
 * Description: A simple plugin to save contact form submissions in the database, designed for the Elementor Pro Form Module
 * Author:      Sean Barton - Tortoise IT
 * Version:     1.1
 * Author URI:  http://www.sean-barton.co.uk
 *
 * Changelog:
 *
 * < V1.0
 * - Initial Version
 * 
 * < V1.1
 * - Fixed for latest version of Elementor Pro
 * 
 */
 
    add_action('plugins_loaded', 'sb_elem_cfd_init');
    
    function sb_elem_cfd_init() {
        add_action('admin_enqueue_scripts', 'sb_elem_cfd_css_enqueue', 9999);
        
        add_action('elementor_pro/forms/mail_sent', 'sb_elem_cfd_mail_sent', 10, 10);
				
        add_action( 'add_meta_boxes', 'sb_elem_cfd_register_meta_box');
        add_action( 'init', 'sb_elem_cfd_pt_init' );
        add_action( 'admin_notices', 'sb_elem_cfd_admin_notice' );
        add_action( 'admin_head', 'sb_elem_cfd_admin_head' );
        
        add_filter('manage_elementor_cf_db_posts_columns', 'sb_elem_cfd_columns_head', 100);
        add_action('manage_elementor_cf_db_posts_custom_column', 'sb_elem_cfd_columns_content', 100, 2);
    }
    
    function sb_elem_cfd_css_enqueue() {
        global $current_screen;
        
        if ($current_screen->id == 'elementor_cf_db') {
            wp_enqueue_script('sb_elem_cfd_js', plugins_url( '/script.js', __FILE__ ));
        }
		}
    
    function sb_elem_cfd_columns_head($defaults) {
        unset($defaults['date']);
        unset($defaults['cb']);
        unset($defaults['title']);
        
        $defaults['cf_elementor_title'] = 'ID';
        $defaults['email'] = 'Patient / Parent Signature';
        $defaults['read'] = 'Information';
        
        return $defaults;
    }
     
    // SHOW THE FEATURED IMAGE
    function sb_elem_cfd_columns_content($column_name, $post_id) {
        $contact = get_post($post_id);
        $data = get_post_meta($post_id, 'sb_elem_cfd', true);
        
        if ($column_name == 'cf_elementor_title') {
            echo '<a href="' . admin_url('post.php?action=edit&post=' . $post_id) . '">View Submission</a>';
        } else if ($column_name == 'read') {
            if ($read = get_post_meta($post_id, 'sb_elem_cfd_read', true)) {
                echo '<span style="color: green;">' . $read['by_name'] . '<br />' . date('Y-m-d H:i', $read['on']) . '</span>';
            } else {
                echo '<span class="dashicons dashicons-email-alt"></span>';
            }
        } else if ($column_name == 'sub_on') {
            if ($data['extra']['submitted_on']) {
                echo '<a href="' . get_permalink($data['extra']['submitted_on_id']) . '">' . $data['extra']['submitted_on'] . '</a>';
            }
        } else if ($column_name == 'sub_date') {
            echo $contact->post_date;
        } else if ($column_name == 'cloned') {
            if ($cloned = get_post_meta($post_id, 'sb_elem_cfd_cloned', true)) {
                $cloned_count = count($cloned);
                
                echo '<span class="dashicons dashicons-yes"></span> (' . $cloned_count . ')';
            } else {
                echo '<span class="dashicons dashicons-no-alt"></span>';
            }
        } else if ($column_name == 'email') {
            if ($email = get_post_meta($post_id, 'sb_elem_cfd_email', true)) {
                $email = '<a href="mailto:' . $email . '" target="_blank">' . $email . '</a>';
            } else {
                $email = '-';
            }
            echo $email;
        }
    }
    
    function sb_elem_cfd_admin_head() {
        global $current_user;
        
        if (isset($_GET['sb-action'])) {
            $action = $_GET['sb-action'];
            
            if ($action == 'mark-all-read') {
                $args = array(
                    'posts_per_page'   => -1,
                    'meta_key'         => 'sb_elem_cfd_read',
                    'meta_value'       => 0,
                    'post_type'        => 'elementor_cf_db',
                    'post_status'      => 'publish',
                );
                
                if ($other_contacts = get_posts( $args )) {
                    foreach ($other_contacts as $other_contact) {
                        $read = array('by_name'=>$current_user->display_name, 'by'=>$current_user->ID, 'on'=>time());
                        update_post_meta($other_contact->ID, 'sb_elem_cfd_read', $read);
                    }
                }
            }
        }
        
        //to hide add new controls
        global $current_screen;
        
        //print_r($current_screen);
        
        echo '<style>#menu-posts-elementor_cf_db .wp-submenu { display: none; }</style>';
        
        if ($current_screen->id == 'edit-elementor_cf_db') {
            echo '<style>
                    .page-title-action, .tablenav, .search-box, .row-actions .inline { display: none; }
                </style>';
        } else if ($current_screen->id == 'elementor_cf_db') {
            echo '<style>
                    #post-body-content, .page-title-action, #postbox-container-1 { display: none; }
                </style>';
        }

    }
    
    function sb_elem_cfd_admin_notice() {
        if (!current_user_can('administrator')) {
            return;
        }
        
        $args = array(
            'posts_per_page'   => -1,
            'meta_key'         => 'sb_elem_cfd_read',
            'meta_value'       => 0,
            'post_type'        => 'elementor_cf_db',
            'post_status'      => 'publish',
        );
        
        if ($other_contacts = get_posts( $args )) {
            //Use notice-warning for a yellow/orange, and notice-info for a blue left border.
            $class = 'notice notice-error is-dismissible';
            $message = __( 'You have ' . count($other_contacts) . ' unread contact form submissions. Click <a href="' . admin_url('edit.php?post_type=elementor_cf_db') . '">here</a> to visit them or click <a href="' . admin_url('edit.php?post_type=elementor_cf_db&sb-action=mark-all-read') . '">here</a> to mark all as read', 'sb_elem_cfd' );
    
            printf( '<div class="%1$s"><p>%2$s</p></div>', $class, $message );
        }
    }

    function sb_elem_cfd_register_meta_box() {
        add_meta_box( 'sb_elem_cfd', esc_html__( 'Form Submission', 'sb_elem_cfd' ), 'sb_elem_cfd_meta_box_callback', 'elementor_cf_db', 'normal', 'high' );
        add_meta_box( 'sb_elem_cfd_extra', esc_html__( 'Extra Information', 'sb_elem_cfd' ), 'sb_elem_cfd_meta_box_callback_extra', 'elementor_cf_db', 'normal', 'high' );
        add_meta_box( 'sb_elem_cfd_actions', esc_html__( 'Actions', 'sb_elem_cfd' ), 'sb_elem_cfd_meta_box_callback_actions', 'elementor_cf_db', 'normal', 'high' );
        add_meta_box( 'sb_elem_cfd_debug', esc_html__( 'Debug/Server Info', 'sb_elem_cfd' ), 'sb_elem_cfd_meta_box_callback_debug', 'elementor_cf_db', 'normal', 'high' );
    }

    function sb_elem_cfd_meta_box_callback() {
        global $current_user;
        
        $submission = get_post(get_the_ID());
        
        if (!$read = get_post_meta(get_the_ID(), 'sb_elem_cfd_read', true)) {
            $read = array('by_name'=>$current_user->display_name, 'by'=>$current_user->ID, 'on'=>time());
            update_post_meta(get_the_ID(), 'sb_elem_cfd_read', $read);
        }
        
        $class = 'notice notice-info';
        $message = 'First read by ' . $read['by_name'] . ' at ' . date('Y-m-d H:i', $read['on']);
        printf( '<div class="%1$s"><p>%2$s</p></div>', $class, $message ); 
    
        if ($data = get_post_meta(get_the_ID(), 'sb_elem_cfd', true)) {
            
            if ($fields = $data['data']) {
                echo '<table class="widefat">
                        <thead>
                        <tr>
                            <th>Label</th>
                            <th>Value</th>
                        </tr>
                        </thead>
                        <tbody>';
                        
                foreach ($fields as $field) {
                    $value = $field['value'];
                    
                    if (is_email($value)) {
                        $value = '<a href="mailto:' . $value . '" target="_blank">' . $value . '</a>';
                    }
                    
                    echo '<tr>
                            <td><strong>' . $field['label'] . '</strong></td>
                            <td>' . wpautop($value) . '</td>
                        </tr>';
                }
                
                echo '<tr>
                            <td><strong>Date of Submission</strong></td>
                            <td>' . $submission->post_date . '</td>
                        </tr>';
                
                echo '</tbody>
                </table>';
            }
        }
    
    }
 
    function sb_elem_cfd_meta_box_callback_extra() {
        $other_submissions = '';
    
        if ($data = get_post_meta(get_the_ID(), 'sb_elem_cfd', true)) {
            if ($extra = $data['extra']) {
                echo '<table class="widefat">
                        <thead>
                        <tr>
                            <th>Label</th>
                            <th>Value</th>
                        </tr>
                        </thead>
                        <tbody>';
                        
                foreach ($extra as $key=>$value) {
                    
                    switch($key) {
                        case 'submitted_on_id':
                        case 'submitted_by_id':
                            continue(2); //we don't really care about these ones
                            break;
                        case 'submitted_on':
                            if ($extra['submitted_on_id']) {
                                $value = $value . ' (<a href="' . get_permalink($extra['submitted_on_id']) . '" target="_blank">View Page</a> | <a href="' . admin_url('post.php?action=edit&post=' . $extra['submitted_on_id']) . '" target="_blank">Edit Page</a>)';
                            } else {
                                $value = '<em>Unknown</em>';
                            }
                            break;
                        case 'submitted_by':
                            if ($extra['submitted_by_id']) {
                                $value = $value . ' (<a href="' . admin_url('user-edit.php?user_id=' . $extra['submitted_by_id']) . '" target="_blank">View User Profiile</a>';
                                
                                $args = array(
                                    'posts_per_page'   => -1,
                                    'meta_key'         => 'sb_elem_cfd_submitted_by',
                                    'meta_value'       => $extra['submitted_by_id'],
                                    'post_type'        => 'elementor_cf_db',
                                    'post_status'      => 'publish',
                                );
                              
                                if ($other_contacts = get_posts( $args )) {
                                    $value .= ' | <a style="cursor: pointer;" onclick="jQuery(\'.other_submissions\').slideToggle();">View ' . count($other_contacts) . ' more submissions by this user</a>';
                                    $other_submissions .= '<div style="display: none;" class="other_submissions">
                                                            <h3>Other submissions made by the same person</h3>';
                                    $other_submissions .= '<table class="widefat">';
                                    
                                    foreach ($other_contacts as $other_contact) {
                                        $other_submissions .= '<tr><td><a href="' . admin_url('post.php?action=edit&post=' . $other_contact->ID) . '">' . $other_contact->post_title . '</a></td></tr>';
                                    }
                                    
                                    $other_submissions .= '</table></div>';
                                }
                                
                                $value .= ')';
                            } else {
                                $value = '<em>Not a registered user</em>';
                            }
                            
                            break;
                    }
                    
                    $key_label = ucwords(str_replace('_', ' ', $key));
                    
                    echo '<tr>
                            <td><strong>' . $key_label . '</strong></td>
                            <td>' . $value . '</td>
                        </tr>';
                }
                
                echo '</tbody>
                </table>';
                
                echo $other_submissions;
            }
            
        }
    
    }
 
    function sb_elem_cfd_meta_box_callback_actions() {
        $submission = get_post(get_the_ID());
        $data = get_post_meta(get_the_ID(), 'sb_elem_cfd', true);
        
        if (isset($_POST['sb_elem_cfd_map_to'])) {
            $map_to = $_POST['sb_elem_cfd_map_to'];
            $map_to_other = $_POST['sb_elem_cfd_map_to_other'];
            
            if ($fields = $data['data']) {
                $mapped_fields = array();
                $custom_fields = array();
                
                foreach ($fields as $field) {
                    $mapped_fields[$field['label']] = $field['value'];
                }
                
                $db_ins = array(
                    'post_title'    => 'Cloned from contact form',
                    'post_content'    => 'Cloned from contact form',
                    'post_status'   => 'draft',
                    'post_type'   => $_POST['sb_elem_cfd_pt'],
                );
                
                if (isset($_POST['sb_elem_cfd_date'])) {
                    $db_ins['post_date'] = $_POST['sb_elem_cfd_date'];
                }
                
                $found = 0;
                
                foreach ($map_to as $key=>$field) {
                    if ($field) {
                        $found++;
                        
                        if ($field == 'custom_field') {
                            if ($map_to_other[$key]) {
                                $custom_fields[$map_to_other[$key]] = $mapped_fields[$key];
                            }
                        } else {
                            $db_ins[$field] = $mapped_fields[$key];
                        }
                    }
                }
                
                if ($found) {
                    // Insert the post into the database
                    if ($post_id = wp_insert_post( $db_ins )) {
                        if (!is_wp_error($post_id)) {
                            foreach ($custom_fields as $key=>$value) {
                                update_post_meta($post_id, $key, $value);
                            }
                            
                            echo '<div id="message" class="updated fade">
                                    <p>Successfully copied the content of this contact form submission to another post type. Click here to <a href="' . get_permalink($post_id) . '">View</a> or <a href="' . admin_url('post.php?action=edit&post=' . $post_id) . '">Edit</a></p>
                                </div>';
                                
                            if (!$cloned = get_post_meta($_GET['post'], 'sb_elem_cfd_cloned', true)) {
                                $cloned = array();
                            }
                            
                            $cloned[$post_id] = time();
                            
                            update_post_meta($_GET['post'], 'sb_elem_cfd_cloned', $cloned);
                            
                        } else {
                            echo '<div id="message" class="error fade">
                                    <p>Oops something went wrong. This error message may be helpful: ' . print_r($post_id, true) . '</p>
                                </div>';
                        }
                    }
                } else {
                    echo '<div id="message" class="error fade">
                            <p>You need to choose at least one field to map against for the clone to work.</p>
                        </div>';
                }
            
                echo '<pre>';
                print_r($db_ins);
                print_r($custom_fields);
                print_r($data['data']);
                print_r($_POST);
                echo '</pre>';
            }
        }
            
        $map_to_options = array();
        $maps = array(
            'post_title'=>'Title'
            , 'post_content'=>'Content'
            , 'custom_field'=>'Custom Field'
        );
        
        foreach ($maps as $key=>$value) {
            $map_to_options[] = '<option value="' . $key . '">' . $value . '</option>';
        }

        $types = get_post_types();
        $type_options = array();
        
        foreach ($types as $type2) {
            $type_obj2 = get_post_type_object($type2);
            
            if (!$type_obj2->public) {
                continue;
            }
            
            $type_options[] = '<option value="' . $type2 . '">' . $type_obj2->labels->name . '</option>';
        }
        
        echo '<p>';
        
        if ($email = get_post_meta(get_the_ID(), 'sb_elem_cfd_email', true)) {
            echo '<a style="margin-right: 10px;" class="button-primary" target="_blank" href="mailto:' . $email . '">Reply via Email</a>';
        }
    
        echo '<a onclick="jQuery(\'.sb_elem_cfd_convert\').slideToggle();" class="button-secondary">Copy to another Post Type</a>';
        
        echo '</p>';
        
        ///////////////////////////////////
        
        echo '<div style="display: none; overflow: scroll;" class="sb_elem_cfd_convert">';
        
        echo '<h3>Copy to another post type</h3>';
        
        echo '<p><label>Select Post Type: <select name="sb_elem_cfd_pt">' . implode('', $type_options) . '</select></label></p>';
        echo '<p>Select Field Mappings:</p>';
        
        echo '<table class="widefat">';
        
        foreach ($data['fields_original']['form_fields'] as $field) {
            echo '<tr>
                    <td>' . $field['field_label'] . '</td>
                    <td>
                        <select name="sb_elem_cfd_map_to[' . $field['field_label'] . ']"><option value="">-- Unused --</option>' . implode('', $map_to_options) . '</select>
                        <span style="margin-left: 20px; display: inline-block;">(If "Custom Field" selected, enter field name: <input type="text" name="sb_elem_cfd_map_to_other[' . $field['field_label'] . ']" />)</span>
                    </td>
                </tr>';
        }
        
        echo '</table>';
        
        echo '<p><label><input type="checkbox" name="sb_elem_cfd_date" value="' . $submission->post_date . '" />&nbsp;Keep date of original submission? (' . $submission->post_date . ')</label></p>';
        echo '<p><input type="submit" class="button-primary sb_elem_cfd_copy" value="Copy" /></p>';
        
        //echo '<pre>';
        //print_r($data['fields_original']);
        //echo '</pre>';
        
        echo '</div>';
        
        if ($cloned = get_post_meta($_GET['post'], 'sb_elem_cfd_cloned', true)) {
            echo '<h3>Clone History</h3>';
            
            echo '<table class="widefat">
                    <thead>
                        <tr>
                            <th>New Post Title</th>
                            <th>Post Type</th>
                            <th>Date Cloned</th>
                            <th>Actions</th>
                        </tr>
                    </thead>';
        
            foreach ($cloned as $cloned_id=>$date) {
                if ($cloned_post = get_post($cloned_id)) {
                    $type_obj = get_post_type_object($cloned_post->post_type);
                    $type_name = $type_obj->labels->name;
                
                    echo '<tr>
                            <td>' . $cloned_post->post_title . '</td>
                            <td>' . $type_name . '</td>
                            <td>' . date('Y-m-d H:i', $date) . '</td>
                            <td><a href="' . get_permalink($cloned_id) . '">View</a> | <a href="' . admin_url('post.php?action=edit&post=' . $post_id) . '">Edit</a></td>
                        </tr>';
                }
            }
            
            echo '</table>';
        
        }
    }
    
    function sb_elem_cfd_meta_box_callback_debug() {
    
        if ($data = get_post_meta(get_the_ID(), 'sb_elem_cfd', true)) {
            echo '<div style="display: none; overflow: scroll;" class="sb_elem_cfd_debug">';
            
            echo '<pre>';
            print_r($data);
            echo '</pre>';
            
            echo '</div>';
            
            echo '<p><a onclick="jQuery(\'.sb_elem_cfd_debug\').slideToggle();" class="button-secondary">Reveal Debug/Server Information</a></p>';
        }
    
    }
    
    function sb_elem_cfd_pt_init() {
        $labels = array(
            'name'               => _x( 'Patient Form1', 'post type general name', 'sb-elementor' ),
            'singular_name'      => _x( 'Patient Form1', 'post type singular name', 'sb-elementor' ),
            'menu_name'          => _x( 'Patient Form1', 'admin menu', 'sb-elementor' ),
            'name_admin_bar'     => _x( 'Patient Form1', 'add new on admin bar', 'sb-elementor' ),
            'add_new'            => _x( 'Add New', 'Form Submissions', 'sb-elementor' ),
            'add_new_item'       => __( 'Add New Form Submissions', 'sb-elementor' ),
            'new_item'           => __( 'New Form Submissions', 'sb-elementor' ),
            'edit_item'          => __( 'Edit Form Submissions', 'sb-elementor' ),
            'view_item'          => __( 'View Form Submissions', 'sb-elementor' ),
            'all_items'          => __( 'All Form Submissions', 'sb-elementor' ),
            'search_items'       => __( 'Search Form Submissions', 'sb-elementor' ),
            'parent_item_colon'  => __( 'Parent Form Submissions:', 'sb-elementor' ),
            'not_found'          => __( 'No contact form submissions found.', 'sb-elementor' ),
            'not_found_in_trash' => __( 'No contact form submissions found in Trash.', 'sb-elementor' )
        );
        
        $args = array(
            'labels'             => $labels,
            'description'        => __( 'For storing contact form submissions.', 'sb-elementor' ),
            'public'             => false,
            'publicly_queryable' => false,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => false,
            'capability_type'    => 'post',
            'has_archive'        => false,
            'hierarchical'       => false,
            'menu_position'      => null,
            'menu_icon'          => 'dashicons-admin-comments',
            'supports'           => array( 'title')
        );
        
        register_post_type( 'elementor_cf_db', $args );
    }
    
    function sb_elem_cfd_mail_sent($settings, $record) {
        global $current_user;
				
				//echo '<pre>';
				//print_r(func_get_args());
				//echo '</pre>';
				//return;
				
        if ($fields = $settings['form_fields']) {
            $data = array();
            
            $email = false;
						
						$value_fields = $record->get( 'fields' );
            
            foreach( $fields as $field_id=>$field ) {
                $label = $field['field_label'];
								$value = $value_fields[$field['_id']]['value'];
                
                if ($field['field_type'] == 'email') {
                    $email = $value;
                }
                
                $data[] = array('label'=>$label, 'value'=>$value);
            }
            
            $this_page = get_post($_POST['post_id']);
            $this_user = false;
            
            if ($this_user_id = (isset($current_user->ID) ? $current_user->ID:0)) {
                if ($this_user = get_userdata($this_user_id)) {
                    $this_user = $this_user->display_name;
                }
            }
            
            $extra = array(
               'submitted_on'=>$this_page->post_title 
               , 'submitted_on_id'=>$this_page->ID 
               , 'submitted_by'=>$this_user
               , 'submitted_by_id'=>$this_user_id
            );
            
            $db_ins = array(
              'post_title'    => $settings['form_name'] . ' - ' . date('Y-m-d H:i:s'),
              'post_status'   => 'publish',
              'post_type'   => 'elementor_cf_db',
            );
             
            // Insert the post into the database
            if ($post_id = wp_insert_post( $db_ins )) {
                update_post_meta($post_id, 'sb_elem_cfd', array('data'=>$data, 'extra'=>$extra, 'fields_original'=>$settings, 'record_original'=>$record, 'post'=>$_POST, 'server'=>$_SERVER));
                
                if ($this_user_id) {
                    update_post_meta($post_id, 'sb_elem_cfd_submitted_by', $this_user_id);
                }
                
                update_post_meta($post_id, 'sb_elem_cfd_read', 0);
                update_post_meta($post_id, 'sb_elem_cfd_email', $email);
            }
        }
    }

function addApplicationWidget() {
    wp_add_dashboard_widget(
                 'submitted_applications',         
                 'Submitted Applications',        
                 'showApplicants' 
        );  
}
add_action( 'wp_dashboard_setup', 'addApplicationWidget' );

function showApplicants() {
    global $wpdb;

    
    $query = $wpdb->prepare("SELECT * FROM 'patient_form' WHERE %d >= '0'", RID);
    $applications = $wpdb->get_results($query);

    foreach ( $applications as $application ) {
        echo $application->title . " " . $application->app_firstName . " " . $application->app_surName . "<br/>";
    }
}
include_once('form.php');
?>