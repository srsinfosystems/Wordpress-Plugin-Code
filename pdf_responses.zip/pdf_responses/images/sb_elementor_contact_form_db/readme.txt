=== Plugin Name ===
Contributors: seanbarton
Donate link: http://paypal.me/seanbarton
Tags: elementor, elementor forms
Requires at least: 4.7.*
Tested up to: 4.7.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
A simple plugin to store Elementor Pro Form submissions
 
== Description ==
 
So I�ve been experimenting with Elementor recently and noticed that a plugin I wrote for Divi could be ported over easily enough to offer similar functionality. Cryptically the functionality is thus.. it stores contact form submissions from the Elementor Pro Form Module in a handy interface on the back end of WP.

To make things even better, this plugin both notifies admin users of unread messages via a banner but also allows you to convert these contact form requests into any other post type. This means you could use a contact form to get people to submit testimonials, case studies or even front end submitted content. It makes a simple contact form into a very versatile module indeed.
 
== Installation ==

Install the plugin like any other. All contact forms using the Elementor Pro Form module will thereafter automatically be recorded in the system. Emails will still be sent as normalso don�t worry about that either!
Visit the admin page and you�ll see a list of form submissions with their dates, page they were submitted on, number of times cloned, etc�
 
 
== Screenshots ==
 
Screenshots available at: https://www.sean-barton.co.uk/2017/04/elementor-contact-form-db-free-plugin/
 
== Changelog ==
 
= 1.0 =
* Initial Release