<?php

	/*

		Plugin Name: PDF Responses

		Plugin URI:  http://ob.teamob.in/online-form

		Description: A plugin for PDF form data view

		Version: 1.0

		Author:  PDF Form

		Tested WordPress Versions: 3.0.5

	*/

add_action('admin_menu', 'my_menu');

	// action function for above hook

	function my_menu() {
	
							add_menu_page( __( 'PDF Responses', 'pdf_responses' ), __( 'PDF Responses', 'pdf_responses' ),'administrator', 'pdf_responses', '','http://ob.teamob.in/wp-content/plugins/pdf_responses/images/pdf1.png' );

		add_submenu_page( 'pdf_responses', __( 'PDF Responses', 'pdf_responses' ), __( 'Lists', 'pdf_responses' ),'administrator', 'pdf_responses', 'pdf_responses','http://ob.teamob.in/wp-content/plugins/pdf_responses/images/pdf1.png' );

		add_submenu_page( 'pdf_responses', __( 'Settings', 'pdf_responses'), __( 'Settings', 'settings' ) ,'administrator', 'settings', 'settings' );

	}
	
	function my_plugin_options() {
    	if (!current_user_can('manage_options'))  {
    		wp_die( __('You do not have sufficient permissions to access this page.') );
    	}
    	echo '<div class="wrap">';
    	echo '<p>Here is where the form would go if I actually had options.</p>';
    	echo '</div>';
    }
    add_action('admin_menu1', 'my_plugin_options');

    function pdf_responses(){
    include_once('form.php');
    }
    
	function settings(){
    include_once('settings.php');
    }
    
    
    ## create database table on installation
    global $jal_db_version;
	$jal_db_version = '1.0';

	function jal_install() {
		global $wpdb;
		global $jal_db_version;

		$table_name = 'pdf_responses';
		$table_name1 = 'pdf_settings';
		
		//$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $table_name (
			id INT NOT NULL AUTO_INCREMENT,
			ref_form varchar(55) NULL,
			inputs LONGTEXT NOT NULL,
			created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id)
		) ;";

			$sql1 = "CREATE TABLE $table_name1 (
				  id INT NOT NULL AUTO_INCREMENT,
				  email VARCHAR(255) NOT NULL,
				  created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
				  PRIMARY KEY (id)
				  );";
				  
				  
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );
		dbDelta( $sql1 );

		add_option( 'jal_db_version', $jal_db_version );
	}

	register_activation_hook( __FILE__, 'jal_install' );
	
	$installed_ver = get_option( "jal_db_version" ); ## check installed version of plugin

		if ( $installed_ver != $jal_db_version ) {
			
			## This code will run if this plugin version is different from installed version

			$table_name = 'pdf_responses';
			
			$table_name1 = 'pdf_settings';
		
			//$charset_collate = $wpdb->get_charset_collate();

			$sql = "CREATE TABLE $table_name (
			id INT NOT NULL AUTO_INCREMENT,
			ref_form varchar(55) NULL,
			inputs LONGTEXT NOT NULL,
			created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id)
			) ;";

			$sql1 = "CREATE TABLE $table_name1 (
				  id INT NOT NULL AUTO_INCREMENT,
				  email VARCHAR(255) NOT NULL,
				  created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
				  PRIMARY KEY (id)
				  );";


			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			dbDelta( $sql );
			dbDelta( $sql1 );

			update_option( "jal_db_version", $jal_db_version );
		}






  

?>