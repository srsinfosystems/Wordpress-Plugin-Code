<?php    
global $wpdb;


$sql = "SELECT id, ref_form, inputs, created  FROM pdf_responses ORDER BY id DESC";
$status = $wpdb -> get_results($sql);
//print_r($status);
?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.3.1.js"></script> 
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
<!-- -->
<?php $domainName = $_SERVER['SERVER_NAME'] ; ?>

<div class="col-xs-12">
    <table class="mainTable">
    	<tr>
    		<td><h2 style="color:#666;margin-bottom: 12%;"><img style="width:18%; " src="http://<?php echo $domainName ; ?>/wp-content/plugins/pdf_responses/images/pdf.png">&nbsp; &nbsp;&nbsp;<span>PDF Responses</span></h2></td>
    	</tr>
    </table>
    
    <table class="data table table-striped nowrap" id="data">
        <thead>
            <tr>
        		<th>Sr. No.</th>
        		<th>Reference Form</th>
        		<th>Date Of Submission</th>
        		<th>Action</th>
        	</tr>
        </thead>
        <tbody>
    	    <?php 
    	    for($i = 0; $i < count($status); $i++) {
    	       $data = $status[$i] -> inputs;
    	       $individual_data = json_decode($data);
    	       $id = $status[$i] -> id;
    	    ?>
    	    <tr>
        	    <td><?php echo $i+1; ?></td>
        	    <td><?php  echo $status[$i] -> ref_form; ?></td>
        	    <td><?php
        	      echo $status[$i] -> created;        	    ?></td>
        	  
        	    <td>
        	        <a onclick="viewRecord(<?php echo $id; ?>)" data-toggle="modal" data-target="#myModal"><i class="glyphicon glyphicon-eye-open"></i></a> 
        	        | 
        	        <a onClick="deleteRecord(<?php echo $id; ?>)"><i class="glyphicon glyphicon-trash"></i></a>
        	   </td>
    	    </tr>
    	    <?php } ?>
        </tbody>
    </table>
    <div class="modal fade viewData" id="myModal" role="dialog">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">Detail Data</h4>
            </div>
            <div class="modal-body">
                <table class="table table-striped">
                    <tbody>
                        <tr></tr>
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    
<style>
    .data, .data td, .data tr, .data th {
        border-collapse: collapse !important;
        text-align: center;
        font-family: "apple-system","BlinkMacSystemFont","Segoe UI","Roboto","Oxygen-Sans","Ubuntu","Cantarell","Helvetica Neue","sans-serif";
    }
    .data th {
        font-weight: 700;
    }
    .data th::after {
        display: none !important;
    }
    .data {
        border: 1px solid #ccc;
    }
    .data thead tr {
        background-color: rgb(136, 136, 136);
        color: #fff;
    }
    .data td, .data tr, .data th {
         padding: 10px;
    }
    .data {
        width: 100%;
    }
    .table-striped > tbody > tr:nth-of-type(2n) {
        background: #f1f1f1;
    }
    .table-striped > tbody > tr:nth-of-type(2n+1) {
        background-color: #e3e3e3;
    }
    .data td a {
        text-decoration : none;
        color: #0085ba;
        cursor: pointer;
    }
    .data td a:hover {
        color: #337ab7;
    }
    .showResult {
        color: green;
        font-weight: bold;
        padding: 5px 0px 20px;
    }
    .showResult1 {
        color: red;
        font-weight: bold;
        padding: 5px 0px 20px;
    }
    .modal-body {
        max-height: calc(100vh - 250px);
        overflow: auto;
    }
    .modal-dialog {
        top: 7%;
    }
    .modal-body table td {width:49%;}
    .modal-body table tr td:first-child {
        font-weight: 600;
    }
    #wpcontent {
        background: #f2f2f2;
    }
    .mainTable h2 {
        font-size: 16.9px;
        font-weight: 700;
    }

.help{width:auto;height:auto;background-color:#fff;
 border: solid 4px #46b450;
    margin-left: 1.4%;
    margin-right: 1.4%;
    padding: 1%;
    margin-top: 1%;
    font-weight:600;}

 .data td,  .data th {    text-align: left;}
</style>

<script>
    $(document).ready(function() {
        var table = $('#data').DataTable( {
            responsive: true
        });
 
    new $.fn.dataTable.FixedHeader( table );
    } );
    function deleteRecord(id) {
        //alert(id);
        if(confirm('Are you sure to delete this record ?'))
        {

var domain_name = window.location.hostname;
            $.ajax({

                url: 'http://'+domain_name+'/wp-content/plugins/pdf_responses/delete.php?action=delete',
                type: 'get',
                data: { 
                    "id": id
                },
                success: function(data) {
                    alert('Record Deleted Successfully!');

                    location.reload();
                },
                error: function(data) {
                    console.log('Error'); 
                    //console.log(data); 
                }
            });
        }
    }
    
    function viewRecord(id){
var domain_name = window.location.hostname;
        $.ajax({
            url: 'http://'+domain_name+'/wp-content/plugins/pdf_responses/delete.php?action=view',
            type: 'get',
            data: { 
                "id": id
            },
            success: function(data) {
                console.log(data);
                $('.viewData .modal-body table').html(data);
            },
            error: function(data) {
                alert('error');
            }
        });
    }
</script>