<?php
/*preg_match_all('#<</T\(([^\)]*)\)/V\(([^\)]*)\)#', $payload, $matches);
$DATA = array_combine($matches[1], $matches[2]);
print_r($DATA);*/

global $wpdb;

//$ref_form = 1;
//$inputs =1;
$table_name = $wpdb->prefix . "pdf_responses";
$wpdb->insert( 'pdf_responses', array(
    'ref_form' => $ref_form,
    'inputs' => $inputs
) );

?>
