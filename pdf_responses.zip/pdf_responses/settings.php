<head><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
 $(".help_span").click(function(){
  $(".help").show();
  $(".settings").hide();
 $(".help_span").css('border-bottom', 'solid 3px orange');
 $(".settings_span").css('border-bottom', 'solid 3px black');
});

 $(".settings_span").click(function(){
  $(".settings").show();
  $(".help").hide();
 $(".settings_span").css('border-bottom', 'solid 3px orange');
 $(".help_span").css('border-bottom', 'solid 3px black');
});

$(".notice-dismiss").click(function(){
  $("#saved").hide();

});



});
</script>
</head>
<body>
<div id="saved" style="display:none;"> 
<p><strong>Settings saved.</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
<?php

global $wpdb;

$domainName = $_SERVER['SERVER_NAME'] ;

 $sql = "SELECT * FROM pdf_settings ORDER BY id DESC Limit 1";
    $result = $wpdb -> get_row($sql);
    $emailId = $result ->email;
?>
 <div class="col-xs-12">
<table class="mainTable">
    	<tr>
    		<td><h2 style="color:#666;margin-left: 5.5%;"><img style="width:20%; vertical-align: middle;" src="http://<?php echo $domainName ; ?>/wp-content/plugins/pdf_responses/images/pdf.png">&nbsp; &nbsp;&nbsp;<span>PDF Responses</span></h2></td>
    	</tr>
    </table></div><hr>
<div class="title1"><span class="help_span">Help</span><span class="settings_span">Settings</span></div>
<div class="help">
<h4>To get PDF data to be save in your domain database, following requirement should be apply.</h4><hr>
Your pdf submit button should follow below url format.
<br> <a href=""> http://<?php echo $domainName ; ?>/wp-content/plugins/pdf_responses/controller.php?action=pdfDataSubmit </a>
</div><hr>

<div class="settings" style="display:none;">
<div class="gen">General  Settings : </div><hr>
<form method="POST" action=''>
 
<div class="email1">Email Address :
<?php if($emailId == " " || $emailId == null){ ?>

<input type="email" name="email" id="email1" value="<?php echo $emailId; ?>" id="email" onblur="validateEmail(this);">&nbsp;&nbsp;<i class="fa fa-check right" style="font-size:24px;color:#46b450; display:none;"></i>

<?php } else { ?>

 <input type="email" name="email" id="email1" value="<?php echo $emailId; ?>" id="email" onblur="validateEmail(this);">&nbsp;&nbsp;<i class="fa fa-check right" style="font-size:24px;color:#46b450"></i>

<?php } ?>
</div><div class="note">*Type an email address here and then click a button below to receive every new response submission from your PDF Form. </div>
<br><hr>
 <br>
<input type="button" name="button1" id="button1"  Value="Save Settings" onclick ="myFunction()">
</form>

</div>
<script>

function myFunction(){	

	var domain_name = window.location.hostname;
	var email = $("#email1").val() ;

  	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

        if (reg.test(email) == false) 
        {
            alert('Invalid Email Address');
            return false;
        }

	if(email == undefined || email == null || email == "" ){
	$(".right").hide();
	alert("please enter your email id");
	return ;
}
$(".right").show();
  $.ajax({

                url: 'http://'+domain_name+'/wp-content/plugins/pdf_responses/delete.php?action=insert',
                type: 'post',
                data: { "email" : email
                    
                },
                success: function(data) {
              //   alert("saved");

		$("#saved").show();
		$(".right").show();

                    
                },
                error: function(data) {
                    console.log('Error'); 
                   
                }
            });
 }


</script>
</body>
<style>
.help{
font-size: 16px;
 line-height: 2.5em;
    margin-left: 1.6%;
}
    
.settings{
font-size: 16px;
 line-height: 2em;
    margin-left: 2%;
}
.title1{
background:#fff;
font-size:18px; 
    padding: 14px;
    margin-top: 2%;
    margin-bottom: 2%;
    margin-right: 2%;
}
.help_span{ 
    margin: 0.3%;
    margin-right: 4%;border-bottom: solid 3px orange;padding-bottom: 10px;}
.settings_span{padding-bottom: 10px;}
.help a{    text-decoration: solid;}
.settings input{    padding: 15px;    margin-left: 2%;
    width: 43%;}
.note{    font-size: 15px;
    margin-left: 16%;}
.email1{    margin-left: 3%;}
#button1{padding:5px;    width: 12%;
    font-size: 16px;
    font-weight: 700;  padding-top: 1%;
    padding-bottom: 1%;background:orange;color:#fff;    margin-left: 0%;}
h4{font-size:15px;}
.gen{    font-size: 18px;}
.heading{    margin-left: 2%;}
.heading span{    
}
#saved{
margin-top: 2%;
margin-right: 2%;
background:#fff;
border-left-color: #46b450;
    padding: 1px 12px;
border-left: solid 4px #46b450;
    margin-left: 18px;
}
.notice-dismiss{
margin-top: 2%;
margin-right: 2%;
}
</style>
