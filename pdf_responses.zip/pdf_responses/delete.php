<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/wp-config.php');
include_once($_SERVER['DOCUMENT_ROOT'].'/wp-load.php');
include_once($_SERVER['DOCUMENT_ROOT'].'/wp-includes/wp-db.php');
$action = $_REQUEST['action'];
//echo $action;
switch($action)
{
    case 'view':
		$content = viewRecord();
	break;
	case 'delete':
		$content = deleteRecord();
	break;

	case 'insert':
		$content = insert();
}
echo $content;

function deleteRecord(){
    global $wpdb; 
    if($wpdb->delete( 'pdf_responses' , array( 'id' => $_REQUEST['id'] ) )){
        echo "Success";
    }
    else {echo "errorInner";}
    return ; 
}

function viewRecord(){
    //return 'ewheruweruywerre';


    global $wpdb; 
    $id = $_REQUEST['id'];
    $sql = "SELECT * FROM pdf_responses WHERE id = $id";
    $result = $wpdb -> get_row($sql);
    $input_data = $result ->inputs;
    $result1 = json_decode(($input_data));
    $result1 = (Array)$result1;
    $html = '';
    foreach($result1 as $key => $val){
        $html .= '<tr><td>'. $key .'</td>';
        $html .= '<td>'. $val .'</td></tr>';
        
    }
    echo $html; exit;
    
}

function insert(){
  global $wpdb; 
  $emailId =  $_POST['email'] ;
echo $emailId ;

$resultQuery = $wpdb->insert('pdf_settings', array(
  'email' => $emailId,
));


}



?>