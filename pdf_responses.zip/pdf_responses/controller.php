<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/wp-config.php');
//include_once($_SERVER['DOCUMENT_ROOT'].'/wp-load.php');

global $wpdb;

$str = file_get_contents('php://input');
$form = parse2($str);

$ref_form =$form['Reference Form'];
$inputs = (json_encode($form));
$table_name = "pdf_responses";

$resultQuery = $wpdb->insert('pdf_responses', array(
    'ref_form' => $ref_form,
    'inputs' => $inputs,
));

 if($resultQuery){
    echo "New record created successfully";
 global $wpdb; 
 $sql = "SELECT * FROM pdf_settings ORDER BY id DESC Limit 1";
    $result = $wpdb -> get_row($sql);
    $emailId = $result ->email;
    $subject = "New Response Received - PDF";
    $domainName = $_SERVER['SERVER_NAME'] ;
$message= "Content-Type: text/html; charset=UTF-8\r\n";
    $message .= '<p>Hello Admin,<br></p><p>A new response has been received from your PDF form. You can view this by signing into  backend<br> http://'.$domainName.'/wp-admin/admin.php?page=pdf_responses</p><br><p>Thank you.</p>';

	if(!empty($emailId)){

		if(mail( $emailId, $subject, $message ))
    			echo "mail sent !";
		else 
    			echo "mail failed ! " ;
	}

} else {
    echo "Error: ";
}

function parse2($file) {
echo $file; 
 if (!preg_match_all("/<<\/T([^>]*)>>/x", $file,$out,PREG_SET_ORDER)){ 
         return;
}
 for ($i=0;$i<count($out);$i++) {
         $pattern = "<</T(.*)/V(.*)>>";
         $thing = $out[$i][1];
         if (eregi($pattern,$out[$i][0],$regs)) {
                 $key = $regs[2];
                 $val = $regs[1];
                 $key = preg_replace("/^\s*\(/","",$key);
                 $key = preg_replace("/\)$/","",$key);
                 $key = preg_replace("/\\\/","",$key);
                 $val = preg_replace("/^\s*\(/","",$val);
                 $val = preg_replace("/\)$/","",$val);
                 $key = str_replace("/Off", "",$key);
		 $key = str_replace("/On", "", $key);
		$matches[$val] = $key;
         }
 }


 return $matches;

}